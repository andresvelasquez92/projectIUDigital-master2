@extends('dashboard.master')
@section('content')
    <h6>Listar  Publicaciones</h6>
@endsection
